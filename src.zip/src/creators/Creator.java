package creators;

import pizzas.Pizza;

public abstract class Creator {

	abstract public Pizza factoryMethod();
	
}
